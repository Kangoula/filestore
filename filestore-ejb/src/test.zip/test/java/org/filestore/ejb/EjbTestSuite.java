package org.filestore.ejb;

import org.filestore.ejb.file.FileItemTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
   FileItemTest.class
})
public class EjbTestSuite {

}
